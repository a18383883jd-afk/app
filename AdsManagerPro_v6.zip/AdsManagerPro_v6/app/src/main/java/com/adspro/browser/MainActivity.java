package com.adspro.browser;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "ads_pro_session_prefs";
    private static final String KEY_ACTIVE_PROFILE = "active_profile_id";

    private WebView browserWebView;
    private WebView assistantWebView;
    private ProgressBar progressBar;
    private boolean isAssistantVisible = false;
    private String currentProfileId = "p1";

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        currentProfileId = prefs.getString(KEY_ACTIVE_PROFILE, "p1");

        try {
            WebView.setDataDirectorySuffix("adspro_" + sanitizeSuffix(currentProfileId));
        } catch (IllegalStateException ignored) {
        }

        setContentView(R.layout.activity_main);

        browserWebView = findViewById(R.id.browserWebView);
        assistantWebView = findViewById(R.id.assistantWebView);
        progressBar = findViewById(R.id.progressBar);

        setupBrowserWebView();
        setupAssistantWebView();

        browserWebView.loadUrl("https://ads.tiktok.com");
        assistantWebView.loadUrl("file:///android_asset/assistant.html");
    }

    private String sanitizeSuffix(String id) {
        if (id == null || id.trim().isEmpty()) return "p1";
        return id.replaceAll("[^a-zA-Z0-9_-]", "_");
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupBrowserWebView() {
        WebSettings settings = browserWebView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        settings.setUserAgentString(
            "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
        );

        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setAcceptThirdPartyCookies(browserWebView, true);

        browserWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                progressBar.setVisibility(View.VISIBLE);
                syncUrlToAssistant(url);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(View.GONE);
                syncUrlToAssistant(url);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    return false;
                }
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(intent);
                } catch (Exception ignored) {
                }
                return true;
            }
        });

        browserWebView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
            }
        });
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupAssistantWebView() {
        WebSettings settings = assistantWebView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);

        assistantWebView.addJavascriptInterface(new NativeBridge(), "AndroidBridge");
    }

    private void syncUrlToAssistant(String url) {
        if (url == null) return;
        String safe = url.replace("\\", "\\\\").replace("'", "\\'");
        assistantWebView.evaluateJavascript("if(window.onBrowserUrlChanged){window.onBrowserUrlChanged('" + safe + "');}", null);
    }

    private void switchToProfileSession(final String newProfileId, final String profileName) {
        runOnUiThread(() -> {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            prefs.edit().putString(KEY_ACTIVE_PROFILE, newProfileId).apply();

            CookieManager cm = CookieManager.getInstance();
            cm.flush();
            browserWebView.clearCache(false);
            browserWebView.loadUrl("https://ads.tiktok.com");
            Toast.makeText(
                MainActivity.this,
                "تم التبديل إلى حساب: " + profileName + " (جلسة منفصلة)",
                Toast.LENGTH_SHORT
            ).show();
            hideAssistant();
        });
    }

    public class NativeBridge {
        @JavascriptInterface
        public void selectAccountProfile(final String profileId, final String profileName) {
            switchToProfileSession(profileId, profileName);
        }

        @JavascriptInterface
        public void openUrl(final String url) {
            runOnUiThread(() -> {
                String target = url == null ? "" : url.trim();
                if (target.isEmpty()) return;
                if (!target.startsWith("http://") && !target.startsWith("https://")) {
                    target = "https://" + target;
                }
                browserWebView.loadUrl(target);
                hideAssistant();
            });
        }

        @JavascriptInterface
        public void goBackBrowser() {
            runOnUiThread(() -> {
                if (browserWebView.canGoBack()) {
                    browserWebView.goBack();
                } else {
                    Toast.makeText(MainActivity.this, "لا توجد صفحة سابقة", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void reloadBrowser() {
            runOnUiThread(() -> browserWebView.reload());
        }

        @JavascriptInterface
        public void toggleAssistant() {
            runOnUiThread(() -> {
                if (isAssistantVisible) {
                    hideAssistant();
                } else {
                    showAssistant();
                }
            });
        }

        @JavascriptInterface
        public void extractCurrentPageText() {
            runOnUiThread(() -> {
                browserWebView.evaluateJavascript(
                    "(function(){ return document.body ? document.body.innerText.slice(0, 6000) : ''; })();",
                    value -> {
                        if (value == null) value = "\"\"";
                        assistantWebView.evaluateJavascript(
                            "if(window.onExtractedPageText){window.onExtractedPageText(" + value + ");}",
                            null
                        );
                    }
                );
            });
        }

        @JavascriptInterface
        public void clearSessionCookies() {
            runOnUiThread(() -> {
                CookieManager.getInstance().removeAllCookies(null);
                CookieManager.getInstance().flush();
                browserWebView.clearCache(true);
                browserWebView.reload();
                Toast.makeText(MainActivity.this, "تم تنظيف الجلسة وملفات الارتباط", Toast.LENGTH_SHORT).show();
            });
        }
    }

    private void showAssistant() {
        isAssistantVisible = true;
        assistantWebView.setVisibility(View.VISIBLE);
    }

    private void hideAssistant() {
        isAssistantVisible = false;
        assistantWebView.setVisibility(View.GONE);
    }

    public void onFabToggleClicked(View view) {
        if (isAssistantVisible) {
            hideAssistant();
        } else {
            showAssistant();
        }
    }

    @Override
    public void onBackPressed() {
        if (isAssistantVisible) {
            hideAssistant();
        } else if (browserWebView.canGoBack()) {
            browserWebView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
